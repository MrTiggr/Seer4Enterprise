﻿// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

using System.Collections.Generic;
using System.IO;
using AdaptiveCards;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.TemplateManager;
using Microsoft.Bot.Schema;
using Newtonsoft.Json;
using VirtualAssistant.Dialogs.Main.Resources;

namespace VirtualAssistant.Dialogs.Main
{
    public class MainResponses : TemplateManager
    {
        private static LanguageTemplateDictionary _responseTemplates = new LanguageTemplateDictionary
        {
            ["default"] = new TemplateIdMap
            {
                {
                    ResponseIds.Cancelled,
                    (context, data) => MessageFactory.Text(MainStrings.CANCELLED, MainStrings.CANCELLED, InputHints.AcceptingInput)
                },
                {
                    ResponseIds.NoActiveDialog,
                    (context, data) => MessageFactory.Text(MainStrings.NO_ACTIVE_DIALOG, MainStrings.NO_ACTIVE_DIALOG, InputHints.AcceptingInput)
                },
                {
                    ResponseIds.Completed,
                    (context, data) => MessageFactory.Text(MainStrings.COMPLETED, MainStrings.COMPLETED, InputHints.AcceptingInput)
                },
                {
                    ResponseIds.Confused,
                    (context, data) => MessageFactory.Text(MainStrings.CONFUSED, MainStrings.CONFUSED, InputHints.AcceptingInput)
                },
                {
                    ResponseIds.Greeting,
                    (context, data) => MessageFactory.Text(MainStrings.GREETING, MainStrings.GREETING, InputHints.AcceptingInput)
                },
                {
                    ResponseIds.Error,
                    (context, data) => MessageFactory.Text(MainStrings.ERROR, MainStrings.ERROR, InputHints.AcceptingInput)
                },
                {
                    ResponseIds.SkillNotFound,
                    (context, data) => MessageFactory.Text(MainStrings.SKILL_NOTFOUND, MainStrings.SKILL_NOTFOUND, InputHints.AcceptingInput)
                },
                {
                    ResponseIds.Help,
                    (context, data) => BuildHelpCard(context, data)
                },
                {
                    ResponseIds.Qna,
                    (context, data) => BuildQnACard(context, data)
                },
            }
        };

        public MainResponses()
        {
            Register(new DictionaryRenderer(_responseTemplates));
        }

        public static IMessageActivity BuildHelpCard(ITurnContext turnContext, dynamic data)
        {
            var attachment = new HeroCard()
            {
                Title = MainStrings.HELP_TITLE,
                Text = MainStrings.HELP_TEXT,
            }.ToAttachment();

            var response = MessageFactory.Attachment(attachment, ssml: MainStrings.HELP_TEXT, inputHint: InputHints.AcceptingInput);

            response.SuggestedActions = new SuggestedActions
            {
                Actions = new List<CardAction>()
                {
                    new CardAction(type: ActionTypes.ImBack, title: MainStrings.CALENDAR_SUGGESTEDACTION, value: MainStrings.CALENDAR_SUGGESTEDACTION),
                    new CardAction(type: ActionTypes.ImBack, title: MainStrings.EMAIL_SUGGESTEDACTION, value: MainStrings.EMAIL_SUGGESTEDACTION),
                    new CardAction(type: ActionTypes.ImBack, title: MainStrings.MEETING_SUGGESTEDACTION, value: MainStrings.MEETING_SUGGESTEDACTION),
                    new CardAction(type: ActionTypes.ImBack, title: MainStrings.POI_SUGGESTEDACTION, value: MainStrings.POI_SUGGESTEDACTION),
                },
            };

            return response;
        }

        public static IMessageActivity BuildQnACard(ITurnContext turnContext, dynamic answer)
        {
            var response = turnContext.Activity.CreateReply();

            try
            {
                // Some Qna responses have cards encoded in them which we verify
                ThumbnailCard card = JsonConvert.DeserializeObject<ThumbnailCard>(answer);

                response.Attachments = new List<Attachment>
                {
                    card.ToAttachment(),
                };

                response.Speak = card.Title != null ? $"{card.Title} " : string.Empty;
                response.Speak += card.Subtitle != null ? $"{card.Subtitle} " : string.Empty;
                response.Speak += card.Text != null ? $"{card.Text} " : string.Empty;
            }
            catch (JsonException)
            {
                response.Text = answer;
                response.Speak = answer;
            }

            // Ensure the InputHint is set to accepting
            response.InputHint = InputHints.AcceptingInput;

            return response;
        }

        public class ResponseIds
        {
            public const string Cancelled = "cancelled";
            public const string Completed = "completed";
            public const string Confused = "confused";
            public const string Greeting = "greeting";
            public const string Help = "help";
            public const string Error = "error";
            public const string NoActiveDialog = "noActiveDialog";
            public const string Qna = "qna";
            public const string SkillNotFound = "skillNotFound";
        }
    }
}