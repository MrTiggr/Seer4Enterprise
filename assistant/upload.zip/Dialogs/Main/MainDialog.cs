﻿// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Luis;
using Microsoft.AspNetCore.Http;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Builder.Solutions.Dialogs;
using Microsoft.Bot.Builder.Solutions.Proactive;
using Microsoft.Bot.Builder.Solutions.Responses;
using Microsoft.Bot.Builder.Solutions.Skills;
using Microsoft.Bot.Builder.Solutions.TaskExtensions;
using Microsoft.Bot.Builder.Solutions.Telemetry;
using Microsoft.Bot.Configuration;
using Microsoft.Bot.Schema;
using Newtonsoft.Json;
using VirtualAssistant.Dialogs.Escalate;
using VirtualAssistant.Dialogs.Main.Resources;
using VirtualAssistant.Dialogs.Onboarding;
using VirtualAssistant.Models;

namespace VirtualAssistant.Dialogs.Main
{
    public class MainDialog : RouterDialog
    {
        // Fields
        private BotServices _services;
        private UserState _userState;
        private ConversationState _conversationState;
        private ProactiveState _proactiveState;
        private EndpointService _endpointService;
        private IBackgroundTaskQueue _backgroundTaskQueue;
        private IHttpContextAccessor _httpContext;
        private IStatePropertyAccessor<OnboardingState> _onboardingState;
        private IStatePropertyAccessor<Dictionary<string, object>> _parametersAccessor;
        private IStatePropertyAccessor<VirtualAssistantState> _virtualAssistantState;
        private ResponseManager _responseManager;
        private string _imageAssetLocation;
        private MainResponses _responder = new MainResponses();
        private SkillRouter _skillRouter;

        private string headerImagePath = "header_greeting.png";
        private string backgroundImagePath = "background_light.png";
        private string columnBackgroundImagePath = "background_dark.png";
        private bool _conversationStarted = false;

        public MainDialog(BotServices services, ConversationState conversationState, UserState userState, ProactiveState proactiveState, EndpointService endpointService, IBotTelemetryClient telemetryClient, IBackgroundTaskQueue backgroundTaskQueue, ResponseManager responseManager, string imageAssetLocation, IHttpContextAccessor httpContext = null)
            : base(nameof(MainDialog), telemetryClient)
        {
            _services = services ?? throw new ArgumentNullException(nameof(services));
            _conversationState = conversationState;
            _userState = userState;
            _proactiveState = proactiveState;
            _endpointService = endpointService;
            TelemetryClient = telemetryClient;
            _backgroundTaskQueue = backgroundTaskQueue;
            _httpContext = httpContext;
            _imageAssetLocation = imageAssetLocation;
            _responseManager = responseManager;
            _onboardingState = _userState.CreateProperty<OnboardingState>(nameof(OnboardingState));
            _parametersAccessor = _userState.CreateProperty<Dictionary<string, object>>("userInfo");
            _virtualAssistantState = _conversationState.CreateProperty<VirtualAssistantState>(nameof(VirtualAssistantState));

            AddDialog(new OnboardingDialog(_services, _onboardingState, telemetryClient));
            AddDialog(new EscalateDialog(_services, telemetryClient));

            RegisterSkills(_services.SkillDefinitions);
        }

        protected override async Task OnStartAsync(DialogContext dc, CancellationToken cancellationToken = default(CancellationToken))
        {
            // if the OnStart call doesn't have the locale info in the activity, we don't take it as a startConversation call
            if (!string.IsNullOrWhiteSpace(dc.Context.Activity.Locale))
            {
                await StartConversation(dc);

                _conversationStarted = true;
            }
        }

        protected override async Task<InterruptionAction> OnInterruptDialogAsync(DialogContext dc, CancellationToken cancellationToken)
        {
            if (dc.Context.Activity.Type == ActivityTypes.Message)
            {
                // Adaptive card responses come through with empty text properties
                if (!string.IsNullOrEmpty(dc.Context.Activity.Text))
                {
                    // get current activity locale
                    var locale = CultureInfo.CurrentUICulture.TwoLetterISOLanguageName;
                    var localeConfig = _services.LocaleConfigurations[locale];

                    // check luis intent
                    var luisService = localeConfig.LuisServices["general"];
                    var luisResult = await luisService.RecognizeAsync<General>(dc.Context, cancellationToken);
                    var intent = luisResult.TopIntent().intent;

                    // TODO - Evolve this pattern
                    if (luisResult.TopIntent().score > 0.5)
                    {
                        switch (intent)
                        {
                            case General.Intent.Logout:
                                {
                                    return await LogoutAsync(dc);
                                }
                        }
                    }
                }
            }

            return InterruptionAction.NoAction;
        }

        protected override async Task RouteAsync(DialogContext dc, CancellationToken cancellationToken = default(CancellationToken))
        {
            var parameters = await _parametersAccessor.GetAsync(dc.Context, () => new Dictionary<string, object>());
            var virtualAssistantState = await _virtualAssistantState.GetAsync(dc.Context, () => new VirtualAssistantState());

            // get current activity locale
            var locale = CultureInfo.CurrentUICulture.TwoLetterISOLanguageName;
            var localeConfig = _services.LocaleConfigurations[locale];

            // No dialog is currently on the stack and we haven't responded to the user
            // Check dispatch result
            var dispatchResult = await localeConfig.DispatchRecognizer.RecognizeAsync<Dispatch>(dc, CancellationToken.None);
            var intent = dispatchResult.TopIntent().intent;

            switch (intent)
            {
                case Dispatch.Intent.l_General:
                    {
                        // If dispatch result is general luis model
                        var luisService = localeConfig.LuisServices["general"];
                        var luisResult = await luisService.RecognizeAsync<General>(dc, CancellationToken.None);
                        var luisIntent = luisResult?.TopIntent().intent;

                        // switch on general intents
                        if (luisResult.TopIntent().score > 0.5)
                        {
                            switch (luisIntent)
                            {
                                case General.Intent.Help:
                                    {
                                        // send help response
                                        await _responder.ReplyWith(dc.Context, MainResponses.ResponseIds.Help);
                                        break;
                                    }

                                case General.Intent.Cancel:
                                    {
                                        // if this was triggered, then there is no active dialog
                                        await _responder.ReplyWith(dc.Context, MainResponses.ResponseIds.NoActiveDialog);
                                        break;
                                    }

                                case General.Intent.Escalate:
                                    {
                                        // start escalate dialog
                                        await dc.BeginDialogAsync(nameof(EscalateDialog));
                                        break;
                                    }

                                case General.Intent.Logout:
                                    {
                                        await LogoutAsync(dc);
                                        break;
                                    }

                                case General.Intent.ShowNext:
                                case General.Intent.ShowPrevious:
                                    {
                                        var lastExecutedIntent = virtualAssistantState.LastIntent;
                                        if (lastExecutedIntent != null)
                                        {
                                            var matchedSkill = _skillRouter.IdentifyRegisteredSkill(lastExecutedIntent);
                                            await RouteToSkillAsync(dc, new SkillDialogOptions()
                                            {
                                                SkillDefinition = matchedSkill,
                                                Parameters = parameters,
                                            });
                                        }

                                        break;
                                    }

                                case General.Intent.None:
                                default:
                                    {
                                        // No intent was identified, send confused message
                                        await _responder.ReplyWith(dc.Context, MainResponses.ResponseIds.Confused);
                                        break;
                                    }
                            }
                        }

                        break;
                    }

                case Dispatch.Intent.l_Calendar:
                case Dispatch.Intent.l_Email:
                case Dispatch.Intent.l_ToDo:
                case Dispatch.Intent.l_PointOfInterest:
                    {
                        virtualAssistantState.LastIntent = intent.ToString();
                        var matchedSkill = _skillRouter.IdentifyRegisteredSkill(intent.ToString());

                        if (matchedSkill != null)
                        {
                            await RouteToSkillAsync(dc, new SkillDialogOptions()
                            {
                                SkillDefinition = matchedSkill,
                                Parameters = parameters,
                            });
                        }
                        else
                        {
                            // Dispatch indicated a skill but we couldn't map to an available skill.
                            await _responder.ReplyWith(dc.Context, MainResponses.ResponseIds.SkillNotFound);
                        }

                        break;
                    }

                case Dispatch.Intent.q_FAQ:
                    {
                        var qnaService = localeConfig.QnAServices["faq"];
                        var answers = await qnaService.GetAnswersAsync(dc.Context);
                        if (answers != null && answers.Count() > 0)
                        {
                            await _responder.ReplyWith(dc.Context, MainResponses.ResponseIds.Qna, answers[0].Answer);
                        }

                        break;
                    }

                case Dispatch.Intent.q_Chitchat:
                    {
                        var qnaService = localeConfig.QnAServices["chitchat"];
                        var answers = await qnaService.GetAnswersAsync(dc.Context);
                        if (answers != null && answers.Count() > 0)
                        {
                            await _responder.ReplyWith(dc.Context, MainResponses.ResponseIds.Qna, answers[0].Answer);
                        }

                        break;
                    }

                case Dispatch.Intent.None:
                default:
                    {
                        // No intent was identified, send confused message
                        await _responder.ReplyWith(dc.Context, MainResponses.ResponseIds.Confused);
                        break;
                    }
            }
        }

        protected override async Task CompleteAsync(DialogContext dc, DialogTurnResult result = null, CancellationToken cancellationToken = default(CancellationToken))
        {
            // End active dialog
            await dc.EndDialogAsync(result);
        }

        protected override async Task OnEventAsync(DialogContext dc, CancellationToken cancellationToken = default(CancellationToken))
        {
            // Indicates whether the event activity should be sent to the active dialog on the stack
            var forward = true;
            var ev = dc.Context.Activity.AsEventActivity();
            var parameters = await _parametersAccessor.GetAsync(dc.Context, () => new Dictionary<string, object>());

            if (!string.IsNullOrEmpty(ev.Name))
            {
                // Send trace to emulator
                var trace = new Activity(type: ActivityTypes.Trace, text: $"Received event: {ev.Name}");
                await dc.Context.SendActivityAsync(trace);

                // see if there's a skillEvent mapping defined with this event
                var skillEvents = _services.SkillEvents;
                if (skillEvents != null && skillEvents.ContainsKey(ev.Name))
                {
                    var skillEvent = skillEvents[ev.Name];

                    var value = ev.Value != null ? JsonConvert.DeserializeObject<Dictionary<string, string>>(ev.Value.ToString()) : null;
                    var skillIds = skillEvent.SkillIds;

                    if (skillIds == null || skillIds.Length == 0)
                    {
                        var errorMessage = "SkillIds is not specified in the skillEventConfig. Without it the assistant doesn't know where to route the message to.";
                        await dc.Context.SendActivityAsync(new Activity(type: ActivityTypes.Trace, text: errorMessage));
                        TelemetryClient.TrackException(new ArgumentException(errorMessage));
                    }

                    dc.Context.Activity.Value = value;
                    foreach (var skillId in skillIds)
                    {
                        var matchedSkill = _skillRouter.IdentifyRegisteredSkill(skillId);
                        if (matchedSkill != null)
                        {
                            await RouteToSkillAsync(dc, new SkillDialogOptions()
                            {
                                SkillDefinition = matchedSkill,
                            });

                            forward = false;
                        }
                        else
                        {
                            // skill id defined in skillEventConfig is wrong
                            var skillList = new List<string>();
                            _services.SkillDefinitions.ForEach(a => skillList.Add(a.DispatchIntent));

                            var errorMessage = $"SkillId {skillId} for the event {ev.Name} in the skillEventConfig is not supported. It should be one of these: {string.Join(',', skillList.ToArray())}.";

                            await dc.Context.SendActivityAsync(new Activity(type: ActivityTypes.Trace, text: errorMessage));
                            TelemetryClient.TrackException(new ArgumentException(errorMessage));
                        }
                    }
                }
                else
                {
                    switch (ev.Name)
                    {
                        case Events.TimezoneEvent:
                            {
                                try
                                {
                                    var timezone = ev.Value.ToString();
                                    var tz = TimeZoneInfo.FindSystemTimeZoneById(timezone);

                                    parameters[ev.Name] = tz;
                                }
                                catch
                                {
                                    await dc.Context.SendActivityAsync(new Activity(type: ActivityTypes.Trace, text: $"Timezone passed could not be mapped to a valid Timezone. Property not set."));
                                }

                                forward = false;
                                break;
                            }

                        case Events.LocationEvent:
                            {
                                parameters[ev.Name] = ev.Value;
                                forward = false;
                                break;
                            }

                        case Events.TokenResponseEvent:
                            {
                                forward = true;
                                break;
                            }

                        case Events.ActiveLocationUpdate:
                        case Events.ActiveRouteUpdate:
                            {
                                var matchedSkill = _skillRouter.IdentifyRegisteredSkill(Dispatch.Intent.l_PointOfInterest.ToString());

                                await RouteToSkillAsync(dc, new SkillDialogOptions()
                                {
                                    SkillDefinition = matchedSkill,
                                });

                                forward = false;
                                break;
                            }

                        case Events.ResetUser:
                            {
                                await dc.Context.SendActivityAsync(new Activity(type: ActivityTypes.Trace, text: "Reset User Event received, clearing down State and Tokens."));

                                // Clear State
                                await _onboardingState.DeleteAsync(dc.Context, cancellationToken);

                                // Clear Tokens
                                var adapter = dc.Context.Adapter as BotFrameworkAdapter;
                                if (adapter != null)
                                {
                                    await adapter.SignOutUserAsync(dc.Context, null, dc.Context.Activity.From.Id, cancellationToken);
                                }

                                forward = false;

                                break;
                            }

                        case Events.StartConversation:
                            {
                                forward = false;

                                if (!_conversationStarted)
                                {
                                    if (string.IsNullOrWhiteSpace(dc.Context.Activity.Locale))
                                    {
                                        // startConversation activity should have locale in it. if not, log it
                                        TelemetryClient.TrackEventEx("NoLocaleInStartConversation", dc.Context.Activity, dc.ActiveDialog?.Id);

                                        break;
                                    }

                                    await StartConversation(dc);

                                    _conversationStarted = true;
                                }

                                break;
                            }

                        default:
                            {
                                await dc.Context.SendActivityAsync(new Activity(type: ActivityTypes.Trace, text: $"Unknown Event {ev.Name} was received but not processed."));
                                forward = false;
                                break;
                            }
                    }
                }

                if (forward)
                {
                    var result = await dc.ContinueDialogAsync();

                    if (result.Status == DialogTurnStatus.Complete)
                    {
                        await CompleteAsync(dc);
                    }
                }
            }
        }

        /// <summary>
        /// Displays a greeting card to new and returning users.
        /// </summary>
        /// <param name="dc">Dialog context.</param>
        /// <param name="cancellationToken">Cancellation token.</param>
        /// <returns>Task.</returns>
        private async Task StartConversation(DialogContext dc, CancellationToken cancellationToken = default(CancellationToken))
        {
            var onboardingState = await _onboardingState.GetAsync(dc.Context, () => new OnboardingState());

            if (string.IsNullOrEmpty(onboardingState.Name))
            {
                var titleResponse = _responseManager.GetResponse(MainDialogResponses.NewUserGreetingTitle);
                var bodyResponse = _responseManager.GetResponse(MainDialogResponses.NewUserGreetingBody);

                var greetingCardData = new GreetingCardModel()
                {
                    HeaderImageUrl = GetCardImageUri(headerImagePath),
                    BackgroundImageUrl = GetCardImageUri(backgroundImagePath),
                    ColumnBackgroundImageUrl = GetCardImageUri(columnBackgroundImagePath),
                    Title = titleResponse.Text,
                    Body = bodyResponse.Text,
                    Speak = string.Format("{0} {1}", titleResponse.Speak, bodyResponse.Speak)
                };

                var card = new Card("NewUserGreeting", greetingCardData);
                var greetingCardMessage = _responseManager.GetCardResponse(card);

                await dc.Context.SendActivityAsync(greetingCardMessage);

                // This is the first time the user is interacting with the bot, so gather onboarding information.
                await dc.BeginDialogAsync(nameof(OnboardingDialog));
            }
            else
            {
                var titleResponse = _responseManager.GetResponse(MainDialogResponses.ReturningUserGreetingTitle, new StringDictionary() { { "Name", onboardingState.Name } });
                var bodyResponse = _responseManager.GetResponse(MainDialogResponses.ReturningUserGreetingBody);

                var greetingCardData = new GreetingCardModel()
                {
                    HeaderImageUrl = GetCardImageUri(headerImagePath),
                    BackgroundImageUrl = GetCardImageUri(backgroundImagePath),
                    ColumnBackgroundImageUrl = GetCardImageUri(columnBackgroundImagePath),
                    Title = titleResponse.Text,
                    Body = bodyResponse.Text,
                    Speak = string.Format("{0} {1}", titleResponse.Speak, bodyResponse.Speak)
                };

                var card = new Card("ReturningUserGreeting", greetingCardData);
                var greetingCardMessage = _responseManager.GetCardResponse(card);

                await dc.Context.SendActivityAsync(greetingCardMessage);

                var greetingMessage = _responseManager.GetResponse(MainDialogResponses.Greeting);
                await dc.Context.SendActivityAsync(greetingMessage);
            }
        }

        private async Task RouteToSkillAsync(DialogContext dc, SkillDialogOptions options)
        {
            // If we can't handle this within the local Bot it's a skill (prefix of s will make this clearer)
            if (options.SkillDefinition != null)
            {
                // We have matched to a Skill
                await dc.Context.SendActivityAsync(new Activity(type: ActivityTypes.Trace, text: $"-->Forwarding your utterance to the {options.SkillDefinition.Name} skill."));

                // Begin the SkillDialog and pass the arguments in
                await dc.BeginDialogAsync(options.SkillDefinition.Id, options);

                // Pass the activity we have
                var result = await dc.ContinueDialogAsync();

                if (result.Status == DialogTurnStatus.Complete)
                {
                    await CompleteAsync(dc);
                }
            }
        }

        private async Task<InterruptionAction> LogoutAsync(DialogContext dc)
        {
            BotFrameworkAdapter adapter;
            var supported = dc.Context.Adapter is BotFrameworkAdapter;
            if (!supported)
            {
                throw new InvalidOperationException("OAuthPrompt.SignOutUser(): not supported by the current adapter");
            }
            else
            {
                adapter = (BotFrameworkAdapter)dc.Context.Adapter;
            }

            await dc.CancelAllDialogsAsync();

            // Sign out user
            var tokens = await adapter.GetTokenStatusAsync(dc.Context, dc.Context.Activity.From.Id);
            foreach (var token in tokens)
            {
                await adapter.SignOutUserAsync(dc.Context, token.ConnectionName);
            }

            await dc.Context.SendActivityAsync(MainStrings.LOGOUT);

            return InterruptionAction.StartedDialog;
        }

        private void RegisterSkills(List<SkillDefinition> skillDefinitions)
        {
            foreach (var definition in skillDefinitions)
            {
                AddDialog(new SkillDialog(definition, _services.SkillConfigurations[definition.Id], _proactiveState, _endpointService, TelemetryClient, _backgroundTaskQueue));
            }

            // Initialize skill dispatcher
            _skillRouter = new SkillRouter(_services.SkillDefinitions);
        }

        private string GetCardImageUri(string imagePath)
        {
            // If we are in local mode we leverage the HttpContext to get the current path to the image assets
            if (_httpContext != null)
            {
                string serverUrl = _httpContext.HttpContext.Request.Scheme + "://" + _httpContext.HttpContext.Request.Host.Value;
                return $"{serverUrl}/images/{imagePath}";
            }
            else
            {
                // Otherwise use a configured image asset location
                if (string.IsNullOrWhiteSpace(_imageAssetLocation))
                {
                    throw new Exception("imageAssetLocation not configured on the skill.");
                }
                else
                {
                    return $"{_imageAssetLocation}/{imagePath}";
                }
            }
        }

        private class Events
        {
            public const string TokenResponseEvent = "tokens/response";
            public const string TimezoneEvent = "IPA.Timezone";
            public const string LocationEvent = "IPA.Location";
            public const string ActiveLocationUpdate = "IPA.ActiveLocation";
            public const string ActiveRouteUpdate = "IPA.ActiveRoute";
            public const string ResetUser = "IPA.ResetUser";
            public const string StartConversation = "startConversation";
        }
    }
}