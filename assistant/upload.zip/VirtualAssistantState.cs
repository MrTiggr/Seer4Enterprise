﻿namespace VirtualAssistant
{
    public class VirtualAssistantState
    {
        /// <summary>
        /// Gets or sets LastIntent.
        /// </summary>
        /// <value>
        /// ToDoTaskContent.
        /// </value>
        public string LastIntent { get; set; }
    }
}
